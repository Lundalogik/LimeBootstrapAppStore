import sys
import time
import limeclient

print ('argument 0:', sys.argv[1])
client = limeclient.LimeClient('[LimeApiUri]', '[LimeApiDb]', False, False)
with client.login('[LimeApiUser]', '[LimeApiPassword]') as c:
    with open(sys.argv[1], encoding='utf-8') as content:
        f = limeclient.ImportFiles(c).create(filename='invoiceheads.csv',content=content)
        f.delimiter = ';'
        f.save()
        invoiceHeads = limeclient.LimeTypes(c).get_by_name('invoice')
        config = limeclient.ImportConfigs(c).create(lime_type=invoiceHeads, importfile=f)
        config.behavior = limeclient.ImportConfig.CreateAndUpdate

        invoiceNr = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_number'], column='invoicenr', key=True)
        config.add_mapping(invoiceNr)

        companyRelation = invoiceHeads.relations['company']
        companyTable = companyRelation.related
        companyNameMapping = limeclient.RelationMapping(column='customerid', relation=companyRelation, key_field=companyTable.fields['vismaid'])
        config.add_mapping(companyNameMapping)

        customerId = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['customerid'], column='customerid', key=False)
        config.add_mapping(customerId)

        customerReference = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['customer_reference'], column='customer_reference', key=False)
        config.add_mapping(customerReference)

        invoiceType = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_type'], column='invoice_type', key=False)
        config.add_mapping(invoiceType)

        serie = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['serie'], column='serie', key=False)
        config.add_mapping(serie)

        invoiceDate = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_date'], column='invoice_date', key=False)
        config.add_mapping(invoiceDate)

        invoiceExpires = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_expires'], column='invoice_expires', key=False)
        config.add_mapping(invoiceExpires)

        invoiceSum = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_sum'], column='invoice_sum', key=False)
        config.add_mapping(invoiceSum)

        invoiceVat = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_vat'], column='invoice_vat', key=False)
        config.add_mapping(invoiceVat)

        invoiceTotalSum = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_total_sum'], column='invoice_total_sum', key=False)
        config.add_mapping(invoiceTotalSum)

        paid = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['paid'], column='paid', key=False)
        config.add_mapping(paid)

        paidDate = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['paid_date'], column='paid_date', key=False)
        config.add_mapping(paidDate)

        invoiceBalance = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_balance'], column='invoice_balance', key=False)
        config.add_mapping(invoiceBalance)

        invoiceShredded = limeclient.SimpleFieldMapping(field=invoiceHeads.fields['invoice_shredded'], column='invoice_shredded', key=False)
        config.add_mapping(invoiceShredded)

        config.save()

        job = limeclient.ImportJobs(c).create(config)
        while True:
            time.sleep(5)
            job = job.refresh()
            print('Current job status: {}'.format(job.status))
            if  job.has_errors:
                print(job.errors.errors[:10])
                break
            if job.status != 'pending' and job.status != 'running':
                break
            


