import sys
import time
import limeclient

print ('argument 0:', sys.argv[1])
client = limeclient.LimeClient('[LimeApiUri]', '[LimeApiDb]', False, False)
with client.login('[LimeApiUser]', '[LimeApiPassword]') as c:
    with open(sys.argv[1], encoding='utf-8') as content:
        f = limeclient.ImportFiles(c).create(filename='invoicerows.csv', content=content)
        f.delimiter = ';'
        f.save()

        invoiceRows = limeclient.LimeTypes(c).get_by_name('invoicerow')
        config = limeclient.ImportConfigs(c).create(lime_type=invoiceRows, importfile=f)
        config.behavior = limeclient.ImportConfig.CreateAndUpdate

        invoiceRelation = invoiceRows.relations['invoice']
        invoiceTable = invoiceRelation.related
        invoiceMapping = limeclient.RelationMapping(column='invoice', relation=invoiceRelation, key_field=invoiceTable.fields['invoice_number'])
        config.add_mapping(invoiceMapping)

        item = limeclient.SimpleFieldMapping(field=invoiceRows.fields['item'], column='item')
        config.add_mapping(item)

        description = limeclient.SimpleFieldMapping(field=invoiceRows.fields['description'], column='description')
        config.add_mapping(description)

        units = limeclient.SimpleFieldMapping(field=invoiceRows.fields['units'], column='units')
        config.add_mapping(units)

        rowValue = limeclient.SimpleFieldMapping(field=invoiceRows.fields['row_value'], column='row_value')
        config.add_mapping(rowValue)

        rowId = limeclient.SimpleFieldMapping(field=invoiceRows.fields['rowid'], column='row_id', key=True)
        config.add_mapping(rowId)

        config.save()

        job = limeclient.ImportJobs(c).create(config)

        while True:
            time.sleep(5)
            job = job.refresh()
            print('Current job status: {}'.format(job.status))
            if  job.has_errors:
                print(job.errors.errors[:10])
                break
            if job.status != 'pending' and job.status != 'running':
                break
            

        
